import com.sun.net.httpserver.HttpServer;
import com.sun.net.httpserver.HttpExchange;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.List;

public class LojaOnline {

    static List<Produto> produtos = new ArrayList<>();

    public static void main(String[] args) throws Exception {

        // Adiciona os doces que serão exibidos na loja.
        produtos.add(new Produto(1, "Brigadeiro", 3.50));
        produtos.add(new Produto(2, "Beijinho", 3.00));
        produtos.add(new Produto(3, "Brownie", 6.50));
        produtos.add(new Produto(4, "Cupcake", 7.00));
        produtos.add(new Produto(5, "Pão de Mel", 5.50));
        produtos.add(new Produto(6, "Trufa de Chocolate", 4.50));

        // Cria o servidor local na porta 8080.
        HttpServer servidor = HttpServer.create(new InetSocketAddress(8080), 0);

        // Cria a rota principal da loja.
        servidor.createContext("/", exchange -> {
            try {
                paginaInicial(exchange);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Cria a rota usada pelo botão "Adicionar ao Carrinho".
        servidor.createContext("/adicionar", exchange -> {
            try {
                adicionarAoCarrinho(exchange);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Inicia o servidor.
        servidor.start();

        // Mostra o endereço no console.
        System.out.println("Loja online rodando em: http://localhost:8080");
    }

    public static void paginaInicial(HttpExchange exchange) throws Exception {

        // Monta o HTML da página.
        StringBuilder html = new StringBuilder();

        html.append("<!DOCTYPE html>");
        html.append("<html lang='pt-br'>");
        html.append("<head>");
        html.append("<meta charset='UTF-8'>");
        html.append("<title>Doceria Online Java</title>");

        // Estilo visual da página.
        html.append("<style>");
        html.append("body { font-family: Arial; background:#fff3f3; margin:0; padding:0; }");
        html.append("header { background:#8B1E3F; color:white; padding:20px; text-align:center; }");
        html.append(".container { width:85%; margin:30px auto; display:grid; grid-template-columns:repeat(3,1fr); gap:20px; }");
        html.append(".produto { background:white; padding:20px; border-radius:12px; box-shadow:0 0 8px #d9a7b0; text-align:center; }");
        html.append(".produto h2 { color:#8B1E3F; }");
        html.append(".preco { color:#2e7d32; font-size:20px; font-weight:bold; }");
        html.append("button { background:#D81B60; color:white; border:none; padding:10px 15px; border-radius:6px; cursor:pointer; }");
        html.append("button:hover { background:#AD1457; }");
        html.append("</style>");

        html.append("</head>");
        html.append("<body>");

        html.append("<header>");
        html.append("<h1>Doceria Online Java</h1>");
        html.append("<p>Exemplo base para atividade de carrinho de compras</p>");
        html.append("</header>");

        html.append("<div class='container'>");

        // Percorre todos os doces cadastrados.
        for (Produto produto : produtos) {

            html.append("<div class='produto'>");

            // Mostra o nome do doce.
            html.append("<h2>").append(produto.getNome()).append("</h2>");

            // Mostra o preço do doce.
            html.append("<p class='preco'>R$ ").append(String.format("%.2f", produto.getPreco())).append("</p>");

            // Botão que envia o id do produto para a rota /adicionar.
            html.append("<a href='/adicionar?id=").append(produto.getId()).append("'>");
            html.append("<button>Adicionar ao Carrinho</button>");
            html.append("</a>");

            html.append("</div>");
        }

        html.append("</div>");
        html.append("</body>");
        html.append("</html>");

        enviarResposta(exchange, html.toString());
    }

    public static void adicionarAoCarrinho(HttpExchange exchange) throws Exception {

        /*
         ============================================================
         PARTE QUE OS ALUNOS DEVERÃO ALTERAR
         ============================================================

         Neste método deve ser criada a lógica do carrinho de compras.

         Atualmente, o botão "Adicionar ao Carrinho" apenas abre esta página
         informando que a função ainda não foi implementada.

         Os alunos deverão implementar:

         1. Capturar o ID do produto pela URL.
            Exemplo:
            /adicionar?id=1

         2. Procurar o produto correspondente dentro da lista "produtos".

         3. Criar uma estrutura para armazenar os itens do carrinho.
            Sugestões:
            - ArrayList
            - HashMap
            - Classe ItemCarrinho

         4. Verificar se o produto já existe no carrinho.
            Se existir, aumentar a quantidade.

         5. Se o produto não existir, adicionar como novo item.

         6. Criar uma página para visualizar o carrinho.

         7. Calcular o valor total da compra.

         8. Criar opções para:
            - remover produto;
            - alterar quantidade;
            - finalizar compra.

         Esta parte ficou incompleta propositalmente.
        */

        String html = """
                <!DOCTYPE html>
                <html lang='pt-br'>
                <head>
                    <meta charset='UTF-8'>
                    <title>Carrinho em Desenvolvimento</title>
                    <style>
                        body {
                            font-family: Arial;
                            background: #fff3f3;
                            text-align: center;
                            padding-top: 80px;
                        }
                        .caixa {
                            background: white;
                            width: 550px;
                            margin: auto;
                            padding: 30px;
                            border-radius: 12px;
                            box-shadow: 0 0 8px #d9a7b0;
                        }
                        h1 {
                            color: #8B1E3F;
                        }
                        a {
                            display: inline-block;
                            margin-top: 20px;
                            text-decoration: none;
                            background: #D81B60;
                            color: white;
                            padding: 10px 20px;
                            border-radius: 6px;
                        }
                        a:hover {
                            background: #AD1457;
                        }
                    </style>
                </head>
                <body>
                    <div class='caixa'>
                        <h1>Carrinho não implementado</h1>
                        <p>Esta função deverá ser desenvolvida pelos alunos.</p>
                        <p>O desafio é criar a lógica do carrinho de compras.</p>
                        <p>O aluno deverá permitir adicionar, remover, alterar quantidade e calcular o total.</p>
                        <a href='/'>Voltar para a loja</a>
                    </div>
                </body>
                </html>
                """;

        enviarResposta(exchange, html);
    }

    public static void enviarResposta(HttpExchange exchange, String resposta) throws Exception {

        // Converte o HTML em bytes.
        byte[] bytes = resposta.getBytes("UTF-8");

        // Informa ao navegador que a resposta é HTML.
        exchange.getResponseHeaders().add("Content-Type", "text/html; charset=UTF-8");

        // Envia o status HTTP 200, indicando sucesso.
        exchange.sendResponseHeaders(200, bytes.length);

        // Abre o canal de saída.
        OutputStream os = exchange.getResponseBody();

        // Escreve o conteúdo HTML no navegador.
        os.write(bytes);

        // Fecha o canal de saída.
        os.close();
    }
}

class Produto {

    // Identificador único do produto.
    private int id;

    // Nome do doce.
    private String nome;

    // Preço do doce.
    private double preco;

    // Construtor usado para criar cada produto.
    public Produto(int id, String nome, double preco) {
        this.id = id;
        this.nome = nome;
        this.preco = preco;
    }

    // Retorna o ID do produto.
    public int getId() {
        return id;
    }

    // Retorna o nome do produto.
    public String getNome() {
        return nome;
    }

    // Retorna o preço do produto.
    public double getPreco() {
        return preco;
    }
}